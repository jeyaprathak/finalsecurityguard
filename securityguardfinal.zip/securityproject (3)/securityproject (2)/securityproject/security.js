var sidenavbar=document.querySelector(".sidenavbar-home");

function shownavbar(){
    sidenavbar.style.display="block";
}
function closenavbar(){
    sidenavbar.style.display="none";
}

function readmore(){
    window.open("aboutpage.html")
}
function seemore(){
    window.open("projectpage.html")
}
function moreservice(){
    window.open("servicepage.html")
}
function openposition(){
    window.open("careerpage.html")
}
function contactus(){
    window.open("contactpage.html")
}
